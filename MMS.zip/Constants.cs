﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MMS
{
  public class Constants
  {

    public static string LOGGED_ON_USER = "LoggedOnUser";

    public static string ERROR_MSG_INVALID_LOGIN = "Invalid Login";
  }
}